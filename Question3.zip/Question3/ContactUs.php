<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css"></script>
<title>Contact Us Form</title>
<style>
#main{
	width:80%;
	height:630px;
	margin:auto;
	border-radius:10px;
	border:#666 solid 1px}
#left{
	width:100%;
		margin-top:6%;
		margin-left:2%;
		border-radius:8px;
		}
h1{
	text-align:center;
	color:#2EB8C7;
	}
	
#right{width:50%;
float:right;
background-color:#95FFCA;
margin-top:-41%;
margin-right:2%;
border-radius:8px;
height:495px;
}
#app{
	margin-left:10%}
	#mssg
    {
		width:80%;
		border-radius:8px;}
		h3{
			text-align:center}
			.error {color: #FF0000;}
    </style>
</head>
<?php
// define variables and set to empty values
$nameError =""; 
$emailError =""; 
$phoneError =""; 
$messageError = "";
$name ="";
$email =""; 
$phone ="";
$message ="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameError = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }
  
  if (empty($_POST["email"])) {
    $emailError = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  if (empty($_POST["phone"])) {
    $phoneError = "Phone is required";
  } else {
    $phone = test_input($_POST["phone"]);
  }

  if (empty($_POST["message"])) {
    $messageError = "Messege is required";
  } else {
    $message = test_input($_POST["message"]);
  }

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<body>
<div id="main">
<h1><u>Contact Us</u></h1>

<div id="left">
<div id="map" style="width:40%;height:450px;background:yellow;"></div>

<script>
function myMap() {
var mapOptions = {
    center: new google.maps.LatLng(-26.260894, 28.034795),
    zoom: 10,
    mapTypeId: google.maps.MapTypeId.HYBRID
}
var map = new google.maps.Map(document.getElementById("map"), mapOptions);
}
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu-916DdpKAjTmJNIgngS6HL_kDIKU0aU&callback=myMap"></script>
</div>

<div id="right">
<p><span class="error">* required field.</span></p>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
<h3>Contact Form</h3>
<div id="app">
 <h4 >Name</h4>
				<input id="name" name="name" type="text"  placeholder="Name" class="form-control" style=" width:80%;font-weight: bold;font-size:11pt;"/><span class="error">* <?php echo $nameError;?></span>
               </div>
              <div id="app">
 <h4 >Phone</h4>
				<input id="phone" name="phone" type="number"  placeholder="Phone" class="form-control" style=" width:80%;font-weight: bold;font-size:11pt;"  /><span class="error">* <?php echo $phoneError;?></span>
               </div>
               <div id="app">
 <h4 >Email</h4>
				<input id="email" name="email" type="eamil"  placeholder="Eamil" class="form-control" style=" width:80%;font-weight: bold;font-size:11pt;"  /><span class="error">* <?php echo $emailError;?></span>
               </div>
               <div id="app">
 <h4 >Message</h4>
 <textarea id="mssg" name="message"></textarea><span class="error">* <?php echo $messageError;?></span>
        </div><br/>
        <input type="submit"  value="Submit" name="Send" class="btn btn-primary"  style="width:20%; margin-top:-25px" />
</div>
</form>
</div>

</body>
</html>