﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Question1
{
    class dbFunctions
    {
        private SqlConnection con;
        private SqlDataAdapter da;
        // private DataSet ds;
        public dbFunctions()
        {
            try
            {
                con = new
                    SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=Y:\MusicCatalog\DBLogin.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        public DataSet search(String sql)
        {
            DataSet ds = new DataSet();
            try
            {
                da = new SqlDataAdapter(sql, con);

                da.Fill(ds);
                con.Close();



            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return ds;
        }

        public DataSet viewData(String table, String sql)
        {
            DataSet ds = new DataSet();
            try
            {
                da = new SqlDataAdapter(sql, con);

                da.Fill(ds, table);
                con.Close();



            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return ds;
        }
        public DataSet insert(String sql)
        {
            DataSet ds = new DataSet();
            try
            {
                da = new SqlDataAdapter(sql, con);

                da.Fill(ds);
                con.Close();



            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return ds;
        }
        public void quiryModifire(String table, String sql)
        {
            DataSet ds = new DataSet();
            da = new SqlDataAdapter(sql, con);
            da.Fill(ds, table);
            con.Close();
        }
    }
}
