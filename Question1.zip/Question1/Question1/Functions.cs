﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;


namespace Question1
{
    class Functions
    {

        dbFunctions log = new dbFunctions();
       
        DataSet ds = new DataSet();
     
        Boolean flag= false;
        public void login(TextBox user, TextBox pass)
        {
            try
            {
                ds = log.viewData("Login", "select * from Login");
                
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    DataRow row = ds.Tables[0].Rows[i];
                   String username = row["username"].ToString();
                   String password = row["password"].ToString();
                    
                    if (username.Equals(user.Text) && password.Equals(pass.Text))
                    {
                        flag = true;
                        Form1 main = new Form1();
                        main.Hide();
                        if (username.Equals("Admin"))
                        {
                            Admin ad = new Admin();
                            ad.ShowDialog();
                        }
                        else
                        {
                            User usr = new User();
                            usr.ShowDialog();
                        }
                       
                        break;
                    }
                    else
                    {
                        flag = false;
                        
                    }
                }
                if (flag == false)
                {
                    MessageBox.Show("Wrong login details");
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        public void addUser(TextBox name, TextBox surname,TextBox user, TextBox pass)
        {
            try
            {
                ds = log.insert("INSERT INTO [user] (name,surname,username, password) VALUES('" +@name.Text+"','"+@surname.Text+"','"+@user.Text+"','"+@pass.Text+"')");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }


    }
}
